-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2021 at 01:46 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4`
--

-- --------------------------------------------------------

--
-- Table structure for table `komik`
--

CREATE TABLE `komik` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `sampul` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `komik`
--

INSERT INTO `komik` (`id`, `judul`, `slug`, `penulis`, `penerbit`, `sampul`, `created_at`, `updated_at`) VALUES
(1, 'Naruto', 'naruto', 'Masashi Kishimoto', 'Shonen Jump', '1.PNG', NULL, '2021-08-16 02:40:55'),
(2, 'One Piece', 'one-piece', 'Eichiro Oda', 'Gramedia', '2.PNG', NULL, '2021-08-15 22:24:45'),
(16, 'Data baru', 'data-baru', 'data', 'data', '1629357014_d630e4f5a840ef3a3b46.png', '2021-08-16 02:43:52', '2021-08-19 02:10:14');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2021-08-19-071228', 'App\\Database\\Migrations\\Orang', 'default', 'App', 1629357566, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orang`
--

CREATE TABLE `orang` (
  `id` int(11) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orang`
--

INSERT INTO `orang` (`id`, `nama`, `alamat`, `created_at`, `updated_at`) VALUES
(1, 'Latika Ellis Farida', 'Kpg. Ketandan No. 411, Surakarta 97393, Kaltara', '1971-12-15 10:49:54', '2021-09-10 00:45:04'),
(2, 'Harsaya Prasasta S.Ked', 'Jln. Wora Wari No. 155, Bandung 93183, Sumsel', '2006-09-03 17:49:20', '2021-09-10 00:45:04'),
(3, 'Cahyo Langgeng Lazuardi S.E.', 'Psr. Sunaryo No. 578, Tegal 37403, Sultra', '1995-02-09 08:15:45', '2021-09-10 00:45:04'),
(4, 'Safina Padma Kusmawati', 'Psr. Babakan No. 93, Palangka Raya 38620, Sulsel', '2002-07-23 23:12:03', '2021-09-10 00:45:04'),
(5, 'Asman Hartana Wahyudin M.Ak', 'Jln. Salam No. 913, Bandung 19193, Lampung', '1995-11-24 12:18:03', '2021-09-10 00:45:04'),
(6, 'Citra Dalima Haryanti', 'Ki. Ketandan No. 588, Sorong 37401, Malut', '2006-07-05 02:42:39', '2021-09-10 00:45:04'),
(7, 'Ganda Nugroho', 'Jln. Badak No. 667, Tangerang Selatan 85521, NTB', '1985-01-19 10:14:24', '2021-09-10 00:45:04'),
(8, 'Aslijan Hakim', 'Jln. Halim No. 757, Sorong 48456, Sumsel', '2011-08-15 18:51:55', '2021-09-10 00:45:04'),
(9, 'Praba Firmansyah', 'Dk. Ki Hajar Dewantara No. 750, Bogor 73489, Sumsel', '2019-07-13 13:55:19', '2021-09-10 00:45:04'),
(10, 'Rahayu Lailasari S.Gz', 'Ds. Tambun No. 309, Magelang 59443, Sulteng', '2004-07-11 18:57:05', '2021-09-10 00:45:04'),
(11, 'Jatmiko Maulana', 'Jln. Bayam No. 100, Metro 42689, Kalbar', '2016-02-07 15:46:37', '2021-09-10 00:45:04'),
(12, 'Dwi Bakianto Halim', 'Ds. Baranang No. 237, Yogyakarta 71197, Jateng', '2017-08-11 11:42:16', '2021-09-10 00:45:04'),
(13, 'Artanto Rajata', 'Ki. BKR No. 278, Palu 75476, Papua', '1982-11-06 21:44:22', '2021-09-10 00:45:04'),
(14, 'Nasrullah Zulkarnain', 'Dk. Sukabumi No. 996, Pagar Alam 37422, Sulteng', '2012-09-28 18:19:36', '2021-09-10 00:45:04'),
(15, 'Gawati Anggraini M.Farm', 'Jln. Peta No. 720, Bukittinggi 35859, Malut', '2006-02-17 10:06:43', '2021-09-10 00:45:04'),
(16, 'Indah Raisa Laksmiwati S.Kom', 'Ki. Bakin No. 593, Salatiga 40353, Gorontalo', '1987-12-29 08:05:34', '2021-09-10 00:45:04'),
(17, 'Ida Namaga', 'Jr. Bata Putih No. 765, Sawahlunto 67893, Gorontalo', '2017-08-18 09:13:48', '2021-09-10 00:45:04'),
(18, 'Langgeng Mustofa', 'Dk. Tambun No. 915, Palembang 40013, Sumut', '1998-12-02 04:18:25', '2021-09-10 00:45:04'),
(19, 'Rahmi Sabrina Laksita M.M.', 'Ki. Kali No. 98, Palangka Raya 66736, Sultra', '1998-01-30 18:02:38', '2021-09-10 00:45:04'),
(20, 'Rachel Aryani', 'Gg. Suharso No. 865, Sungai Penuh 90287, Sumut', '1994-09-23 12:54:58', '2021-09-10 00:45:04'),
(21, 'Pangeran Kanda Hutasoit S.Pd', 'Gg. Yos No. 808, Administrasi Jakarta Utara 33495, Aceh', '2019-11-25 12:16:20', '2021-09-10 00:45:05'),
(22, 'Akarsana Budiman', 'Dk. Tambun No. 988, Jayapura 47999, Kalbar', '1986-08-20 21:20:18', '2021-09-10 00:45:05'),
(23, 'Hani Eka Kuswandari', 'Jln. Teuku Umar No. 832, Pekalongan 26402, Jateng', '1980-09-14 21:55:06', '2021-09-10 00:45:05'),
(24, 'Cemeti Prayoga', 'Jr. Dahlia No. 41, Lhokseumawe 43938, Banten', '1981-07-16 06:42:53', '2021-09-10 00:45:05'),
(25, 'Hana Shania Yolanda S.Farm', 'Dk. Ronggowarsito No. 29, Pekanbaru 38650, Kalteng', '1975-01-06 15:17:08', '2021-09-10 00:45:05'),
(26, 'Cakrabuana Cengkal Utama M.Ak', 'Ds. Kartini No. 762, Pariaman 47340, NTB', '1970-04-01 19:52:59', '2021-09-10 00:45:05'),
(27, 'Nilam Utami', 'Ki. Acordion No. 22, Administrasi Jakarta Utara 52052, Sulsel', '2004-10-11 07:13:06', '2021-09-10 00:45:05'),
(28, 'Kuncara Mahfud Sihotang S.Sos', 'Kpg. Sutan Syahrir No. 30, Samarinda 44508, Maluku', '1970-02-15 04:14:49', '2021-09-10 00:45:05'),
(29, 'Lasmanto Nugroho', 'Dk. Babadan No. 745, Pekanbaru 58393, Bengkulu', '2009-09-19 04:19:00', '2021-09-10 00:45:05'),
(30, 'Halima Puspita', 'Jln. Wahidin Sudirohusodo No. 673, Cilegon 53039, Kalbar', '1991-01-24 00:45:18', '2021-09-10 00:45:05'),
(31, 'Darmana Sitorus', 'Psr. Baha No. 563, Pagar Alam 13725, Sulteng', '2005-06-12 02:09:24', '2021-09-10 00:45:05'),
(32, 'Perkasa Pradana S.Gz', 'Ds. Jambu No. 725, Tegal 53567, Maluku', '1979-02-21 14:04:01', '2021-09-10 00:45:05'),
(33, 'Wisnu Lulut Napitupulu', 'Ds. Baung No. 623, Pontianak 35174, Sulut', '1981-04-02 09:18:28', '2021-09-10 00:45:05'),
(34, 'Harja Wahyudin S.Pt', 'Dk. Baing No. 265, Padangpanjang 14215, Kalbar', '2015-11-13 01:03:37', '2021-09-10 00:45:05'),
(35, 'Wani Namaga', 'Psr. Sadang Serang No. 325, Sukabumi 11947, Bali', '2007-03-14 04:23:26', '2021-09-10 00:45:05'),
(36, 'Cinta Pratiwi M.Kom.', 'Kpg. Industri No. 374, Cimahi 16129, Babel', '2021-07-14 03:00:18', '2021-09-10 00:45:05'),
(37, 'Kartika Lidya Mardhiyah M.TI.', 'Ds. Barasak No. 519, Palu 10216, Sulut', '2007-04-07 19:51:47', '2021-09-10 00:45:05'),
(38, 'Wisnu Habibi', 'Ds. Sutami No. 431, Padang 75248, Jateng', '2015-10-08 09:42:23', '2021-09-10 00:45:05'),
(39, 'Makuta Irawan', 'Ds. Bakti No. 814, Pekalongan 96570, Pabar', '1975-01-20 04:03:53', '2021-09-10 00:45:05'),
(40, 'Carla Salimah Pertiwi S.Farm', 'Jln. Kalimalang No. 155, Kupang 16270, Sulbar', '2005-07-22 14:57:59', '2021-09-10 00:45:05'),
(41, 'Paulin Sudiati', 'Kpg. Ciwastra No. 975, Batu 63292, Kepri', '2010-04-10 04:30:45', '2021-09-10 00:45:05'),
(42, 'Puti Qori Hasanah S.Ked', 'Jr. Rajawali Barat No. 517, Pontianak 37948, Sultra', '2021-07-25 09:50:14', '2021-09-10 00:45:05'),
(43, 'Fathonah Wulan Nuraini', 'Ds. Nakula No. 235, Padangpanjang 41081, Kaltara', '1992-01-22 16:22:04', '2021-09-10 00:45:05'),
(44, 'Halima Maryati S.Psi', 'Kpg. Salam No. 89, Payakumbuh 65783, NTT', '2011-09-16 01:30:21', '2021-09-10 00:45:05'),
(45, 'Luis Mulya Ardianto S.E.', 'Psr. Ters. Buah Batu No. 838, Malang 48990, NTB', '2004-01-06 13:58:47', '2021-09-10 00:45:05'),
(46, 'Padma Wijayanti', 'Kpg. Peta No. 480, Bogor 90238, Sulsel', '1985-05-29 08:12:27', '2021-09-10 00:45:05'),
(47, 'Hasta Maheswara', 'Dk. Cemara No. 360, Sibolga 45643, Malut', '2021-06-11 10:55:12', '2021-09-10 00:45:05'),
(48, 'Ade Farah Wulandari', 'Kpg. Rumah Sakit No. 258, Subulussalam 29040, Sulteng', '1985-01-31 00:48:44', '2021-09-10 00:45:05'),
(49, 'Jaya Pratama', 'Kpg. Yos No. 562, Sawahlunto 91434, Sulut', '2010-07-31 04:03:53', '2021-09-10 00:45:05'),
(50, 'Luthfi Mansur', 'Jln. Baabur Royan No. 28, Bekasi 48330, Kaltim', '1988-01-02 21:15:00', '2021-09-10 00:45:05'),
(51, 'Leo Mansur', 'Kpg. Ekonomi No. 410, Tegal 23468, DIY', '2019-07-15 04:21:28', '2021-09-10 00:45:05'),
(52, 'Ulya Sudiati', 'Jln. Nangka No. 583, Cirebon 18265, Aceh', '2009-02-20 04:08:13', '2021-09-10 00:45:05'),
(53, 'Sakura Utami M.Ak', 'Jln. B.Agam Dlm No. 974, Tanjungbalai 29172, Sulteng', '2005-09-30 07:26:31', '2021-09-10 00:45:06'),
(54, 'Olga Wahyudin', 'Kpg. Moch. Toha No. 706, Pagar Alam 37495, Sulbar', '1990-05-29 09:06:25', '2021-09-10 00:45:06'),
(55, 'Ghaliyati Mardhiyah M.M.', 'Jr. Salak No. 186, Palopo 79799, Gorontalo', '1971-01-09 11:51:52', '2021-09-10 00:45:06'),
(56, 'Gabriella Aryani', 'Psr. Raya Ujungberung No. 323, Gunungsitoli 18532, Kalteng', '1973-10-03 07:20:43', '2021-09-10 00:45:06'),
(57, 'Daliono Wibisono', 'Gg. Baranangsiang No. 968, Tangerang 25470, NTB', '1982-07-12 06:36:15', '2021-09-10 00:45:06'),
(58, 'Karsa Heryanto Hutasoit', 'Kpg. Pattimura No. 560, Makassar 59152, Sulteng', '1973-07-13 06:31:49', '2021-09-10 00:45:06'),
(59, 'Nalar Irawan', 'Jln. Astana Anyar No. 37, Kendari 44045, Sulteng', '2006-12-31 05:36:21', '2021-09-10 00:45:06'),
(60, 'Safina Indah Astuti S.E.I', 'Jr. Juanda No. 16, Medan 28413, DKI', '1988-08-01 20:16:59', '2021-09-10 00:45:06'),
(61, 'Vino Kusumo', 'Dk. Otto No. 824, Pariaman 51669, Gorontalo', '2016-10-23 19:53:55', '2021-09-10 00:45:06'),
(62, 'Darsirah Rafid Mustofa S.Sos', 'Ki. Bayan No. 8, Kupang 72085, Kalsel', '1973-09-16 11:01:19', '2021-09-10 00:45:06'),
(63, 'Kamidin Hidayat S.T.', 'Jln. Supomo No. 812, Tegal 52367, Banten', '2012-02-29 23:53:18', '2021-09-10 00:45:06'),
(64, 'Rusman Damanik', 'Gg. R.E. Martadinata No. 998, Salatiga 41758, DKI', '2021-09-03 18:12:44', '2021-09-10 00:45:06'),
(65, 'Teddy Wira Wibowo', 'Jln. Suniaraja No. 690, Kupang 74971, Sulteng', '1985-10-01 02:09:23', '2021-09-10 00:45:06'),
(66, 'Ratih Farida', 'Dk. Banceng Pondok No. 886, Gunungsitoli 15613, Sulut', '2004-09-19 17:47:59', '2021-09-10 00:45:06'),
(67, 'Daliman Mangunsong', 'Dk. Raya Ujungberung No. 413, Tanjung Pinang 20767, Banten', '2017-04-15 17:00:11', '2021-09-10 00:45:06'),
(68, 'Banawa Hutagalung', 'Ds. Acordion No. 790, Pontianak 67290, Kepri', '2011-02-26 00:43:51', '2021-09-10 00:45:06'),
(69, 'Cinta Ina Andriani', 'Kpg. Salatiga No. 635, Subulussalam 12741, NTT', '1980-04-20 10:51:10', '2021-09-10 00:45:06'),
(70, 'Ulva Ade Purwanti', 'Ds. Bakin No. 30, Sukabumi 64469, Jambi', '1992-04-29 21:32:35', '2021-09-10 00:45:06'),
(71, 'Ega Maryadi Prasetya M.Farm', 'Psr. Basuki Rahmat  No. 706, Administrasi Jakarta Pusat 83023, Sumbar', '1992-07-28 03:58:10', '2021-09-10 00:45:06'),
(72, 'Hendra Haryanto', 'Dk. Baja Raya No. 191, Langsa 77201, Sumsel', '2015-06-04 03:13:17', '2021-09-10 00:45:06'),
(73, 'Chelsea Novitasari', 'Ds. M.T. Haryono No. 896, Pariaman 78009, Kaltim', '1981-11-30 03:53:38', '2021-09-10 00:45:06'),
(74, 'Restu Gilda Widiastuti', 'Dk. Pasteur No. 867, Mojokerto 42002, Jambi', '1993-12-21 05:17:18', '2021-09-10 00:45:06'),
(75, 'Cindy Hassanah', 'Ds. Pattimura No. 601, Palembang 64546, Maluku', '1988-01-06 02:20:09', '2021-09-10 00:45:06'),
(76, 'Kezia Fathonah Wijayanti', 'Ki. Ciumbuleuit No. 166, Administrasi Jakarta Utara 82880, Papua', '1993-03-12 22:37:51', '2021-09-10 00:45:06'),
(77, 'Darman Simanjuntak S.IP', 'Jln. Suryo No. 368, Pasuruan 79294, Kalbar', '1983-01-30 18:10:40', '2021-09-10 00:45:06'),
(78, 'Cagak Irawan M.Ak', 'Kpg. Tambak No. 135, Kupang 46983, Babel', '1992-07-24 13:20:24', '2021-09-10 00:45:06'),
(79, 'Elisa Uyainah M.Pd', 'Ki. Bambu No. 342, Batu 72149, Sulut', '2007-01-17 11:56:19', '2021-09-10 00:45:06'),
(80, 'Pia Andriani', 'Kpg. Ketandan No. 427, Tidore Kepulauan 23631, Kepri', '1973-10-27 10:59:43', '2021-09-10 00:45:06'),
(81, 'Harsaya Sihotang', 'Ki. Kali No. 558, Kupang 84202, Riau', '2011-10-01 15:43:42', '2021-09-10 00:45:06'),
(82, 'Dadap Halim', 'Gg. Rajawali No. 865, Banjarbaru 24307, Jateng', '2017-09-07 12:08:18', '2021-09-10 00:45:07'),
(83, 'Akarsana Salahudin', 'Dk. Kyai Gede No. 363, Banjar 82830, Sumbar', '1970-09-09 21:42:34', '2021-09-10 00:45:07'),
(84, 'Silvia Padmi Mulyani', 'Jr. Moch. Ramdan No. 975, Sibolga 87296, Sumut', '2008-05-03 23:44:21', '2021-09-10 00:45:07'),
(85, 'Violet Nasyiah S.Ked', 'Jr. Barat No. 682, Makassar 81530, Jambi', '1999-03-11 05:52:04', '2021-09-10 00:45:07'),
(86, 'Daryani Opan Saptono S.Pt', 'Kpg. Bass No. 77, Banjarbaru 39649, Malut', '1993-12-15 22:57:57', '2021-09-10 00:45:07'),
(87, 'Cakrawala Mangunsong', 'Psr. Dr. Junjunan No. 837, Bandung 34925, Kepri', '1972-07-21 13:03:09', '2021-09-10 00:45:07'),
(88, 'Julia Pertiwi', 'Jln. Tentara Pelajar No. 393, Sukabumi 44899, Kepri', '1993-02-16 14:30:25', '2021-09-10 00:45:07'),
(89, 'Novi Keisha Yulianti', 'Gg. Daan No. 814, Bogor 27763, Bali', '1973-07-01 07:28:21', '2021-09-10 00:45:07'),
(90, 'Nadine Winarsih S.Psi', 'Kpg. Bakau No. 152, Tidore Kepulauan 75917, Babel', '2019-11-01 19:44:50', '2021-09-10 00:45:07'),
(91, 'Atmaja Kusumo', 'Kpg. Jakarta No. 413, Padang 79744, Bengkulu', '1971-05-22 17:13:54', '2021-09-10 00:45:07'),
(92, 'Uchita Hastuti', 'Ki. Basuki Rahmat  No. 20, Langsa 37125, Sulsel', '1991-12-27 02:59:01', '2021-09-10 00:45:07'),
(93, 'Tiara Palastri', 'Jr. Abang No. 194, Administrasi Jakarta Barat 70147, Bengkulu', '1972-08-04 18:43:45', '2021-09-10 00:45:07'),
(94, 'Warta Kusumo', 'Psr. Yap Tjwan Bing No. 677, Payakumbuh 48298, Jambi', '1984-07-24 13:38:38', '2021-09-10 00:45:07'),
(95, 'Clara Rahayu', 'Psr. Asia Afrika No. 961, Probolinggo 77236, Bengkulu', '1989-10-11 11:05:13', '2021-09-10 00:45:07'),
(96, 'Kamila Janet Safitri S.Pd', 'Kpg. Tambun No. 733, Pasuruan 64226, Banten', '1977-11-25 10:43:35', '2021-09-10 00:45:07'),
(97, 'Zelaya Palastri', 'Ds. Kalimalang No. 749, Ambon 82493, Lampung', '2011-05-30 11:45:33', '2021-09-10 00:45:07'),
(98, 'Usman Jail Nainggolan S.E.I', 'Dk. Acordion No. 322, Pasuruan 58941, Lampung', '1975-04-14 22:41:55', '2021-09-10 00:45:07'),
(99, 'Sabrina Ellis Hartati', 'Ds. Nangka No. 307, Kendari 46114, Pabar', '2011-02-07 12:46:00', '2021-09-10 00:45:07'),
(100, 'Putu Mansur', 'Gg. Sudirman No. 377, Depok 70896, Bengkulu', '1995-02-07 22:42:56', '2021-09-10 00:45:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `komik`
--
ALTER TABLE `komik`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orang`
--
ALTER TABLE `orang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `komik`
--
ALTER TABLE `komik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orang`
--
ALTER TABLE `orang`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
